This is the final folder to hold all the code utilized by the application developed. 
There will be 2 folders)
  1: App Code
  2: Interesting plots generated in the exploratory analysis.
  
Please refer to all_code to see how the scraping/plotting/machine learning process was performed.
