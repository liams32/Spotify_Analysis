Draft code for Flask app

to launch app use:

python3 app.py or python app.py in terminal
