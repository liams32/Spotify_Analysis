interesting plots generated in EDA
