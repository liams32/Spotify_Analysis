analysis by genre
