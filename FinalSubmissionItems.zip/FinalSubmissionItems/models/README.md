final notebook to generate models

https://drive.google.com/drive/folders/1-zUiFuAWMrYW-liw-qg9VRDRl49XjpLS?usp=sharing for csvs
